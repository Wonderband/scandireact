export const selectProducts = state => state.products.products;
export const selectPending = state => state.products.pending;

