export const Page404 = () => {
  return <div>I`m 404 page</div>;
};
